# История версий
___
# 5.0.0
## 08.04.2026 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2865)
* [PMI-1501](https://jira.just-ai.com/browse/PMI-1501) Перевод на es6 и правки сценария
___
# 4.28.2
## 16.03.2026 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2847)
* [PMI-1453](https://jira.just-ai.com/browse/PMI-1453) Поправлена логика проставления статуса при автоответчике
___
# 4.28.1
## 19.01.2026 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2805)
* [PMI-1341](https://jira.just-ai.com/browse/PMI-1341) & [PMI-1340](https://jira.just-ai.com/browse/PMI-1340) Исправлены паттерны и перебивание
___
# 4.28.0
## 19.01.2026 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2799)
* [PMI-1334](https://jira.just-ai.com/browse/PMI-1334) Обновлена логика вывода прощания для всех сценариев
___
# 4.27.0
## 22.12.2025 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2788)
* [PMI-1284](https://jira.just-ai.com/browse/PMI-1284) Обновлены речевки на оценке NPS, обновлена логика INTRO для моделей устройства, приветственные аудио поделены на два
___
# 4.26.0
## 08.12.2025 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2769)
* [PMI-1240](https://jira.just-ai.com/browse/PMI-1240) Добавлены новые сценарии
___
# 4.25.2
## 13.11.2025 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2758)
* [PMI-1248](https://jira.just-ai.com/browse/PMI-1248) Исправлено дублирование ответов в аналитику
___
# 4.25.1
## 10.11.2025 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2756)
* Исправлен вывод реплик
___
# 4.25.0
## 27.10.2025 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2743)
* [PMI-1157](https://jira.just-ai.com/browse/PMI-1157) Рефакторинг вывода реплик и добавление новой реакции
___
# 4.24.1
## 09.10.2025 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2730)
* [PMI-1171](https://jira.just-ai.com/browse/PMI-1171) Таймаут внешних запрососв снижен до 10 секунд
___
# 4.24.0
## 06.10.2025 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2711)
* [PMI-1067](https://jira.just-ai.com/browse/PMI-1067) Добавлено устройство lil solid dual
___
# 4.23.1
## 06.10.2025 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2718)
* [PMI-979](https://jira.just-ai.com/browse/PMI-979) Перезаписаны стартовые реплики с именем
___
# 4.23.0
## 29.09.2025 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2717)
* [PMI-1113](https://jira.just-ai.com/browse/PMI-1113) Добавлен A/B тест для /Start
___
# 4.22.4
## 29.09.2025 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2714)
* [PMI-1099](https://jira.just-ai.com/browse/PMI-1099) Правки паттернов с числительными
___
# 4.22.3
## 15.08.2025 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2687)
* [PMI-963](https://jira.just-ai.com/browse/PMI-963) Замена аудио при прощании
___
# 4.22.1
## 08.09.2025 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2693)
* [PMI-984](https://jira.just-ai.com/browse/PMI-984) Правка паттерна в YesSmoke
___
# 4.22.0
## 08.09.2025 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2685)
* [PMI-967](https://jira.just-ai.com/browse/PMI-967) Добавлена логика реакци бота, в зависимости от контекста ответа
___
# 4.21.1
## 18.08.2025 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2672)
* [PMI-924](https://jira.just-ai.com/browse/PMI-924) Замена аудио для lil Hybrid
___
# 4.21.0
## 11.08.2025 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2668)
* [PMI-933](https://jira.just-ai.com/browse/PMI-933) Обновлены приветственные реплики для сценариев Sale With Device и Sale Without Device. Добавлены кастомные прощания
___
# 4.20.2
## 11.08.2025 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2667)
* [PMI-930](https://jira.just-ai.com/browse/PMI-930) Исправлен объект ответа
___
# 4.20.1
## 28.07.2025 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2653)
* [PMI-876](https://jira.just-ai.com/browse/PMI-876) Правка паттернов и изменение логики простановки оценки: если клиент называет оценку больше 10, то фиксируем это как 10
___
# 4.20.0
## 14.07.2025 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2641)
* [PMI-845](https://jira.just-ai.com/browse/PMI-845) Обновлены сценарии Lenging End и Guided Trial
___
# 4.19.0
## 14.07.2025 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2640)
* [PMI-842](https://jira.just-ai.com/browse/PMI-842) Обновлен сценарий Sale Self Reg
___
# 4.18.0
## 14.07.2025 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2637)
* [PMI-824](https://jira.just-ai.com/browse/PMI-824) Обновлены сценарии Professional Cleaning, Completed Refund и Replacement Unsuccessful. Добавлены сценарии Replacement_Successful_BR и Replacement_Successful_TT
___
# 4.17.0
## 03.07.2025 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2639)
* [PMI-821](https://jira.just-ai.com/browse/PMI-821) Обновлены сценарии Delivery_Successful и Replacement Delivery Successful и добавлен новый сценарий Delivery_Successful_With_Device
___
# 4.16.1
## 17.06.2025 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2630)
* [PMI-688/692/694/698](https://jira.just-ai.com/browse/PMI-688) Правки на проде
___
# 4.16.0
## 17.06.2025 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2615)
* [PMI-688/692/694/698](https://jira.just-ai.com/browse/PMI-688) Добавлены новые сценарии: Transactional_Surveys_RestartUpgrade, Transactional_Surveys_RestartRecycle, Transactional_Surveys_Premiums, PMI.NPS_Lending_Start
___
# 4.15.0
## ??.04.2025 [pull reuqest](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2588)
* [PMI-597](https://jira.just-ai.com/browse/PMI-597) Отключено A/B тестирование при запросе эмоций для сценариев NPS_Replacement_Successful, NPS_Sale_With_Device, NPS_Professional_Cleaning
___
# 4.14.0
## 10.04.2025 [pull reuqest](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2573)
* [PMI-523](https://jira.just-ai.com/browse/PMI-523) Добавлено A/B тестирование при запросе эмоций для сценариев NPS_Replacement_Successful, NPS_Sale_With_Device, NPS_Professional_Cleaning
___
# 4.13.0
## 12.03.2025 [pull reuqest](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2565)
* [PMI-475](https://jira.just-ai.com/browse/PMI-475) Убрано АВ-тестирование для Obscenity и NoMoreCalls
___
# 4.12.1
## 12.03.2025 [pull reuqest](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2558)
* [PMI-435](https://jira.just-ai.com/browse/PMI-435) Добавлена запись ненормативной лексики в комментарии
___
# 4.12.0
## 11.03.2025 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2562)
* [PMI-446](https://jira.just-ai.com/browse/PMI-446) Добавлены новые сценарии: NPS_Guided_Trial, NPS_Replacement_Unsuccessful, NPS_Completed_Refund
___
# 4.11.0
## 10.02.2025 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2544)
* [PMI-226](https://jira.just-ai.com/browse/PMI-266) Добавлена интеграция с RobotMIA
___
# 4.10.2
## 20.01.2025 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2514)
* [PMI-332](https://jira.just-ai.com/browse/PMI-332) Убрана логика с паттерном $endOfReason из стейта GetComment
___
# 4.10.1
## 15.01.2025 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2524)
* Исправлена ошибка при попадании в CantHearYou
___
# 4.10.0
## 13.01.2025 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2497)
* [PMI-284](https://jira.just-ai.com/browse/PMI-284) Добавлено АВ-тестирование для Obscenity и NoMoreCalls
___
# 4.9.1
## 25.12.2024 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2511)
* [PMI-307](https://jira.just-ai.com/browse/PMI-307) Исправлена логика проставление статуса
___
# 4.9.0
## 18.11.2024 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2474)
* [PMI-220](https://jira.just-ai.com/browse/PMI-220) Исправлены стейт Repeat и просьба перезвона при опросе
___
# 4.8.8
## 14.10.2024 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2434)
* [PMI-138](https://jira.just-ai.com/browse/PMI-138) Исправлены паттерны эмоций
___
# 4.8.7
## 09.10.2024 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2429)
* [RCLT-19241](https://jira.just-ai.com/browse/RCLT-19241) Добавление externalId в отчет при входящем звонке
___
# 4.8.6
## 07.10.2024 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2422)
* [RCLT-19395](https://jira.just-ai.com/browse/RCLT-19395) Повторная отправка запроса в API при входящих звонках
___
# 4.8.5
## 02.10.2024 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2331)
* [PMI-14](https://jira.just-ai.com/browse/PMI-14) Исправлен статус "Приветствие-входящий звонок"
___
# 4.8.4
## 30.09.2024 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2408)
* [PMI-119](https://jira.just-ai.com/browse/PMI-119) Правки сценарной ошибки в метриках
___
# 4.8.3
## 27.09.2024 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2387)
* [PMI-60](https://jira.just-ai.com/browse/PMI-65) Изменена запись данных в SubmittedReply и Reply
___
# 4.8.2
## 17.09.2024 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2368)
* [PMI-60](https://jira.just-ai.com/browse/PMI-60) Добавлены метрики
___
# 4.8.1
## 09.09.2024 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2333)
* [RCLT-19316](https://jira.just-ai.com/browse/RCLT-19316) Исправление паттернов перезвона, поиска имени в словаре
___
# 4.8.0
## 15.08.2024 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2249)
* [RCLT-19150](https://jira.just-ai.com/browse/RCLT-19150) Рефакторинг паттернов
___
# 4.7.1
## 14.08.2024 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2273)
* [RCLT-19292](https://jira.just-ai.com/browse/RCLT-19292) Добавление недостающего аудио
___
# 4.7.0
## 13.08.2024 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/1953)
* [RCLT-17915](https://jira.just-ai.com/browse/RCLT-17915) Подключение callback bot
___
# 4.6.0
## 12.08.2024 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2263)
* [RCLT-18883](https://jira.just-ai.com/browse/RCLT-18883) Добавлено обращение по имени клиента в стартовой реплике и в NPS
___
# 4.5.0
## 22.07.2024 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2085)
* [RCLT-18408](https://jira.just-ai.com/browse/RCLT-18408) Добавлена отправка багов в тг-бот
___
# 4.4.0
## 22.07.2024 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2196)
* [RCLT-18474](https://jira.just-ai.com/browse/RCLT-18474) Добавлен доп. звонок при технической ошибке 
___
# 4.3.0
## 24.06.2024 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2121)
* [RCLT-18567](https://jira.just-ai.com/browse/RCLT-18567) Добавлены стейты AgainYouCalling, CantHearYou, добавлено перебивание по эмоциям 
__
# 4.2.0
## 11.07.2024 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2175)
* [RCLT-18866](https://jira.just-ai.com/browse/RCLT-18866) Добавлен сценарий Professional Cleaning, убраны модели устройств из маппинга
___
# 4.1.3
## 11.07.2024 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2156)
* [RCLT-18882](https://jira.just-ai.com/browse/RCLT-18882) Исправлен переход из Redial по паттерну $yesHaveTime
___
# 4.1.2
## 10.07.2024 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2149)
* [RCLT-18752](https://jira.just-ai.com/browse/RCLT-18752) Добавлен повторый вызов API при отправке NPS-опроса
___
# 4.1.1
## 10.07.2024 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2137)
* [RCLT-18751](https://jira.just-ai.com/browse/RCLT-18751) Добавлено активное слушание в стейт Comment
___
# 4.0.1
## 10.07.2024 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2150)
* [RCLT-18750](https://jira.just-ai.com/browse/RCLT-18750) Добавлено перебивание в запросе оценки
___
# 4.0.0
## 10.07.2024 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2140)
* [RCLT-18572](https://jira.just-ai.com/browse/RCLT-18572) Чувствительные данные вынесены на платформу, добавлено стандартное логирование сессий
___
# 3.1.0
## 24.06.2024 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2095)
* [RCLT-18561](https://jira.just-ai.com/browse/RCLT-18561) Добавлены ответы и новые сценарные коды для устройств
___
# 3.0.1
## 10.06.2024 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/2053)
* [RCLT-18440](https://jira.just-ai.com/browse/RCLT-18440) Изменены паттерны оценки, содержащие числительные, и добавлено удаление ответов автоответчика при отправке в CRM
___
# 3.0.0
## 14.05.2024 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/1911)
* [RCLT-17568](https://jira.just-ai.com/browse/RCLT-17568) Переход на BPMSoft 
___
# 2.1.0
## 26.04.2024 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/1966)
* [RCLT-17764](https://jira.just-ai.com/browse/RCLT-17764) Новая логика в стейте DontSmoke
___
# 2.0.0
## 02.05.2024 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/compare/trans-template-test...transactional-test?from_project_id=2533&straight=false)
* [RCLT-17984](https://jira.just-ai.com/browse/RCLT-17984) Убрана ветка template из проекта 
___
# 1.6.4
## 12.04.2024 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/1912)
* [RCLT-17746](https://jira.just-ai.com/browse/RCLT-17746) Исправлена верхняя граница словесной оценки 
___
# 1.6.3
## 28.03.2024 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/1856)
* [RCLT-17529](https://jira.just-ai.com/browse/RCLT-17529) Изменены вероятности флоу
___
# 1.6.2
## 20.03.2024 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/1777)
* [RCLT-17276](https://jira.just-ai.com/browse/RCLT-17276) Исправлено заполнение полей отчета (Delight Emotion/Expectation текст)
___
# 1.6.1
## 18.03.2024 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/1801)
* [RCLT-17365](https://jira.just-ai.com/browse/RCLT-17365) Добавлено событие onCallNotConnectedTechnical
___
# 1.6.0
## 14.03.2024 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/1785)
* [RCLT-17317](https://jira.just-ai.com/browse/RCLT-17317) Изменены вероятности для флоу, изменен алгоритм выбора сценария, добавлено очищение клиента в конце звонка
___
# 1.5.1
## 12.03.2024 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/1733)
* [RCLT-16838](https://jira.just-ai.com/browse/RCLT-16838) Добавлена реплика прощания с Яндекс.Картами
___
# 1.5.0
## 25.02.2024 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/1724)
* [RCLT-16732](https://jira.just-ai.com/browse/RCLT-16732) Добавлен Main Delight флоу, новый сценарий Professional cleaning
___
# 1.4.0
## 25.01.2024 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/1676)
* [RCLT-15949](https://jira.just-ai.com/browse/RCLT-15949) Добавлен Main и Additional флоу
___
# 1.3.4
## 24.11.2023 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/1566)
* [RCLT-15456](https://jira.just-ai.com/browse/RCLT-15456) Добавлено Main флоу NPS
___
# 1.3.3
## 20.11.2023 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/1554)
* [RCLT-15444](https://jira.just-ai.com/browse/RCLT-15444) Замена аудио в стейте Rate
___
# 1.3.2
## 08.11.2023 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/1514)
* [RCLT-15115](https://jira.just-ai.com/browse/RCLT-15115) Сделан доступ в стейт ItsAnsweringMachine только из Start и Rate
___
# 1.3.1
## 31.10.2023 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/1518)
* [RCLT-15198](https://jira.just-ai.com/browse/RCLT-15198) Исправлен вызов функции для корректной работы перебивания
___
# 1.3.0
## 28.08.2023 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/1338)
* [RCLT-14124](https://jira.just-ai.com/browse/RCLT-14124) Добавлено перебивание
___

# 1.2.1
## 25.09.2023 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/1386)
* [RCLT-14415](https://jira.just-ai.com/browse/RCLT-14415) Добавлена логика для A/B тестирования
___
# 1.2.0
## 25.09.2023 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/1451)
* [RCLT-14657](https://jira.just-ai.com/browse/RCLT-14657) Убрана возможность перезвона
___
# 1.1.6
## 18.09.2023 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/1407)
* [RCLT-14510](https://jira.just-ai.com/browse/RCLT-14510) В Comment добавлен вариант "P LIL Solid 2.0 Plus"
___
# 1.1.5
## 04.09.2023 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/1354)
* [RCLT-14128](https://jira.just-ai.com/browse/RCLT-14128) Увеличено время ожидания причины
___
# 1.1.4
## 17.08.2023 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/1327)
* [RCLT-14164](https://jira.just-ai.com/browse/RCLT-14164) Подключена аналитика для отчета
___
# 1.1.3
## 16.08.2023 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/1321)
* [RCLT-14123](https://jira.just-ai.com/browse/RCLT-14123) Добавлен паттерн в DontSmoke, добавлены тесты
___
# 1.1.2
## 28.07.2023 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/1275)
* [RCLT-13687](https://jira.just-ai.com/browse/RCLT-13687) Удалено получение токена
___
# 1.1.1
## 28.07.2023 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/1246)
* [RCLT-13827](https://jira.just-ai.com/browse/RCLT-13827) $recommendNotToSmoke добавлен в GetReason
* Common version: 1.3.2
___
# 1.1.0
## 28.07.2023 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/1234)
* [RCLT-13683](https://jira.just-ai.com/browse/RCLT-13683) Авторизация перенесена в $client
___
# 1.0.0
## 22.06.2023 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/1146)
* [RCLT-12792](https://jira.just-ai.com/browse/RCLT-12792) Введено версионирование
* Common version: 1.0.0
___
## 20.06.2023 [commit](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/commit/ad4ff9560c3c83828293e0e66339a44cc85cef0e)
* [RCLT-13052](https://jira.just-ai.com/browse/RCLT-13052) Размещение в проде, с новым коммоном и всеми правками из тестовой ветки
___
## 10.05.2023 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/959)
* [RCLT-11342](https://jira.just-ai.com/browse/RCLT-11342) Рефакторинг рудиментов BNPS
___
## 03.04.2023 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/859)
* [RCLT-11156](https://jira.just-ai.com/browse/RCLT-11156) Добавлены 13 сценариев
___
## 30.03.2023 [pull request](https://gitlab.just-ai.com/jaicp-dsl-bots/philip-morris-content/-/merge_requests/907)
* [RCLT-11401](https://jira.just-ai.com/browse/RCLT-11401) Убраны некорректные статусы
