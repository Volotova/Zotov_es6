global.handleBotHangUp = async function() {
    await handleClientHangUp();
}

global.handleClientHangUp = async function() {
    if ($.session.nps?.results?.length) {
        const questionsData = $.session.nps.results;
        const scenarioCode = $.session.nps.structure?.scenario_code;
        const timeStamp = $.session.nps.timeStamp;
        const externalId = $.session.currentExternalId;
        await sendNpsResult(questionsData, scenarioCode, externalId, timeStamp);
    }
}

export default {
    answerBargeInEmotions() {
        const emotions = $Emotions["Default"];
        for (const [index, el] of Object.entries(emotions)) {
            Answer.fromObject(el, index);
        }
    }
}