import moment from "moment";

global.NPSScenario = class NPSScenario {
    constructor() {
        this.__className__ = "NPSScenario";
    }

    init() {
        this.name = this._getScenarioName();
        this.structure = $Scenarios[this.name];
        this.lengthWithComments = this._getLengthWithComments();
        this.length = this.structure.questionsIds.length;
        this.currentQuestionIndex = -1;
        this.currentQuestionId = null;
        this.question = null;
        this.isLastQuestion = false;
        Logger.info("[NPSScenario] Initialized scenario", this);
        return this;
    }

    _getScenarioName() {
        let scenarioName = $session.currentCampaign?.data?.scenario;
        if (scenarioName) return scenarioName;

        const DEFAULT_SCENARIO = 'PMI.NPS_Sale_With_Device';
        const botId = $.request.channelBotId;
        scenarioName = Object.keys($Scenarios).find(
            key => $Scenarios[key].botIds.includes(botId)
        );
        if (!scenarioName) {
            scenarioName = DEFAULT_SCENARIO;
            Logger.warn(`NO SCENARIO FOUND. Setting default: ${DEFAULT_SCENARIO}`);
        }
        return scenarioName;
    }

    _getLengthWithComments() {
        const questions = this.structure.questionsIds;
        let length = 0;
        questions.forEach(
            id => length += ($Questions[id]?.commentByAnswer ? 2 : 1)
        )
        return length;
    }

    nextQuestion() {
        this.currentQuestionIndex++;
        this.currentQuestionId = this.structure.questionsIds[this.currentQuestionIndex];
        const id = this.currentQuestionId;
        this.question = (id !== undefined) ? $Questions[id] : null;
        if (this.question) {
            this.question.commonAnswers ||= this.question.marketingPerformance;
            this.question.callStatus ||= this.question.marketingPerformance;
            if (this.question.type == "scale") {
                const scales = $Scales[this.question.scale || "DelightEmotion"];
                this.question.potentialAnswers = Object.values(scales);
                this.question.answersValues = Object.keys(scales);
            }
            Logger.info("[nps.nextQuestion] Initialized new question", this.question);
        } else {
            Logger.info("[nps.nextQuestion] No more questions");
        }
        this.isLastQuestion = (this.length - 1) <= this.currentQuestionIndex;
        return this.question;
    }

    saveResult(value, query, questionId) {
        let questionInfo;
        if (questionId) {
            questionInfo = $Questions[questionId];
        } else {
            questionId = this.currentQuestionId;
            questionInfo = this.question;
        }
        this.addToBPMData(questionInfo, value, query)
    }
    
    saveComment(query, commentInfo) {
        this.addToBPMData(commentInfo, query, query);
    }
    
    addToBPMData(questionInfo, value, query) {
        // Забираем формулировку вопроса
        const brand = $.session.currentCampaign?.data?.brand; 
        const device = $.session.currentCampaign?.data?.device;
        let questionAsked;
        if (questionInfo.text) {
            questionAsked = questionInfo.text;
            if (device && questionAsked.device) {
                questionAsked = questionAsked.device;
            } else if (brand && questionAsked.brand) {
                questionAsked = questionAsked.brand;
            }
        } else {
            questionAsked = questionInfo.phrase;
            if (device && questionAsked.device) {
                questionAsked = questionAsked.device;
            } else if (brand && questionAsked.brand) {
                questionAsked = questionAsked.brand;
            }
            questionAsked = questionAsked.text || questionAsked.tts;
        }
        
        // Формируем остальные данные
        const questionCode = `${this.structure.scenario_code}_${questionInfo.bpmId}`;
        const currentTime = moment().format();
        const data = {
            "$type": "PMI.BDDM.Transactionaldata.TextAnswer",
            "AskDate": currentTime,
            "QuestionAsked": questionAsked,
            "QuestionCode": questionCode,
            "ReplyDate": currentTime,
            "SubmittedReply": query,
            "Reply": String(value)
        }
        this.results ||= [];
        this.results.push(data);
        this.timeStamp = currentTime;
        Logger.info("[addToBPMData] NPS Answer saved. Current results array", this.results);
    }
}

export default {}