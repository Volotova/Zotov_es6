function checkScale(text) {
    var potentialPatterns = $.session.nps.question.potentialAnswers;
    potentialPatterns = _.map(potentialPatterns, function(el) {
        return [el];
    });
    var match = $nlp.matchPatterns(text, potentialPatterns);
    if (match) {
        $.temp.bargeInIndex = match.targetState;
    }
}
