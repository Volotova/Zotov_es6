theme: /Blocks

    state: LongListening
        scriptEs6:
            $session.currentTagArgs = Utils.cloneDeep($request.data.args);
            try {
                $session.currentTagArgs.duration = parseInt($session.currentTagArgs.duration);
            } catch (e) {
                $session.currentTagArgs.duration = 60;
                Logger.warn("[LongListening] Couldn't parse duration as integer. Setting default.");
            }
            try {
                if ($session.currentTagArgs.question) {
                    $session.currentTagArgs.question = JSON.parse($session.currentTagArgs.question);
                }
                $session.currentTagArgs.silencePhrases = JSON.parse($session.currentTagArgs.silencePhrases);
            } catch (e) {
                Logger.warn("[LongListening] Couldn't parse phrases");
            }
            if ($session.currentTagArgs.silenceLimit) {
                $session.currentTagArgs.silenceLimit = parseInt($session.currentTagArgs.silenceLimit);
            } else {
                $session.currentTagArgs.silenceLimit = 1;
            }
            Logger.info("[LongListening] Start processing tag with parameters", await $session.currentTagArgs);
            $session.currentTagData = {};
            $session.currentTagData.startDT = $jsapi.currentTime();
            $session.currentTagData.commentArr = [];
            if ($session.currentTagArgs.question) {
                Answer.fromObject($session.currentTagArgs.question);
            }
            $dialer.setNoInputTimeout(10000);

        state: GetComment
            event: lengthLimit
            q: *
            q: $dontSmoke
            scriptEs6:
                const currentTagArgs = $session.currentTagArgs;
                const currentTagData = $session.currentTagData;
                currentTagData.commentArr ||= [];
                if ($request.query) {
                    currentTagData.commentArr.push($request.query);
                }
                currentTagData.saidComment = true;
                
                const timePassed = (($jsapi.currentTime() - currentTagData.startDT) / 1000);
                Logger.info(`[LongListening] timePassed: ${timePassed}`);
                if (Utils.testMode() || !Utils.isResterisk() || timePassed >= currentTagArgs.duration) {
                    $reactions.transition("../EndProcessing");
                } else {
                    $dialer.setNoInputTimeout(2000);
                }

        state: Silence
            event: speechNotRecognized
            q: а
            q: $regexp</testSilence>
            scriptEs6:
                // $session.currentTagArgs.silencePhrases
                const currentTagArgs = $session.currentTagArgs;
                const currentTagData = $session.currentTagData;
                const tagName = $session.currentTagArgs.name;

                if (currentTagData.commentArr?.length) {
                    $reactions.transition("../EndProcessing");
                    return;
                }
                const currentCounter = counter(`${tagName}_silence`);
                if (currentCounter <= currentTagArgs.silenceLimit) {
                    Answer.fromObject(currentTagArgs.silencePhrases);
                    $dialer.setNoInputTimeout(10000);
                } else {
                    $temp.longListeningResult = {
                        status: "Silence"
                    }
                    const silenceState = currentTagArgs.silenceState || currentTagArgs.okState;
                    delete $session.currentTagData;
                    delete $session.currentTagArgs;
                    $reactions.transition(silenceState);
                }

        state: EndProcessing
            scriptEs6:
                const commentArr = $session.currentTagData?.commentArr;
                let transition;
                if (commentArr) {
                    transition = $session.currentTagArgs.okState;
                    let comment = $session.currentTagData.commentArr.join(" ");
                    if (comment.length >= 10000) {
                        comment = comment.slice(0, 9999);
                    }
                    $temp.longListeningResult = {
                        status: "OK",
                        comment: comment
                    }
                } else {
                    transition = $session.currentTagArgs.errorState || $session.currentTagArgs.okState;
                    $temp.longListeningResult = {
                        status: "Error"
                    }
                }
                delete $session.currentTagData;
                delete $session.currentTagArgs;
                $reactions.transition(transition);

        state: LocalHangUp
            event: hangup
            scriptEs6:
                const transition = $session.currentTagArgs.hangUpState || $session.currentTagArgs.okState;
                const currentTagData = $session.currentTagData;
                if ($request.query) {
                    currentTagData.commentArr ||= [];
                    currentTagData.commentArr.push($request.query);
                }
                let comment;
                if (currentTagData.commentArr?.length) {
                    comment = currentTagData.commentArr.join(" ");
                    if (comment.length >= 10000) {
                        comment = comment.slice(0, 9999);
                    }
                }
                $temp.longListeningResult = {
                    status: "HangUp",
                    comment: comment
                }
                delete $session.currentTagData;
                delete $session.currentTagArgs;
                $reactions.transition(transition);

        state: YouAreRobot
            q: $youAreRobot
            scriptEs6:
                if ($session.currentTagArgs.robotState && !$session.currentTagData?.commentArr?.length) {
                    go($session.currentTagArgs.robotState);
                    $temp.longListeningResult = {
                        status: "YouAreRobot"
                    };
                    go($session.currentTagArgs.robotState);
                    delete $session.currentTagData;
                    delete $session.currentTagArgs;
                } else {
                    go("../GetComment")
                }
                
        state: NoMoreCalls
            q: $noMoreCalls
            if: $session.currentTagArgs.noMoreCallsState
                scriptEs6:
                    const currentTagData = $session.currentTagData;
                    currentTagData.commentArr ||= [];
                    currentTagData.commentArr.push($request.query);
                    const comment = currentTagData.commentArr.join(" ");
                    $temp.longListeningResult = {
                        status: "NoMoreCalls",
                        comment: comment
                    }
                    go($session.currentTagArgs.noMoreCallsState)
                    delete $session.currentTagData;
                    delete $session.currentTagArgs;
            else:
                go!: ../GetComment