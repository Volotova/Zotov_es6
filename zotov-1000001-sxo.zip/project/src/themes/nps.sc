# TODO refactoring
init:
    bind(
        "preProcess",
        function(ctx) {
            if (ctx.temp.bargeInIndex) {
                ctx.temp.detectedAnswerIndex = ctx.temp.bargeInIndex;
                if (ctx.contextPath === "/NPS/AskQuestion/WaitForScaleAnswer/NoEmotions") {
                    ctx.temp.targetState = "/NPS/AskQuestion/WaitForScaleAnswer/GetAnswer";
                } else {
                    ctx.temp.targetState = ctx.contextPath + "/GetAnswer";
                }
            } else if (ctx.session.nps && ctx.session.nps.question && ctx.session.nps.question.potentialAnswers) {
                // Для вопросов типа scale проверяем отдельно, была ли названа оценка
                log("RUN PREPROCESS PARSING");
                var potentialAnswers = ctx.session.nps.question.potentialAnswers;
                if (potentialAnswers && Array.isArray(potentialAnswers)) {
                    // Для каждого элемента массива потенциальных ответов проверяем матчинг
                    var result = $nlp.matchPatterns(ctx.parseTree.text, potentialAnswers);
                    log("Preprocess parsing result: " + toPrettyString(result));
                    /* Если есть ответ матчится с одним из потенциальных,
                    вес матчинга сравниваем с весом попадания в стейты текущего контекста */
                    if (result && result.score) {
                        var nluScore = (ctx.nluResults && ctx.nluResults.selected && ctx.nluResults.selected.score)
                            ? ctx.nluResults.selected.score : 0;
                        log("NLU Score: " + toPrettyString(nluScore));
                        if (result.score >= nluScore) {
                            // Сохраняем индекс сработавшего паттерна и переходим в стейт записи ответа
                            ctx.temp.detectedAnswerIndex = result.targetState;
                            if (ctx.contextPath === "/NPS/AskQuestion/WaitForScaleAnswer/NoEmotions") {
                                ctx.temp.targetState = "/NPS/AskQuestion/WaitForScaleAnswer/GetAnswer";
                            } else {
                                ctx.temp.targetState = ctx.contextPath + "/GetAnswer";
                            }
                        }
                    }
                }
            }
        },
        "/NPS/AskQuestion",
        "Check for NPS answer"
    );

theme: /NPS

    state: InitQuestion
        scriptEs6:
            const question = (await session()).nps.nextQuestion();
            if (!question) {
                if ($session.wasInNoEmotions) {
                    Answer.say("NoEmotions_LastQuestion");
                    HangUp.hangUp();
                } else {
                    go("/Goodbye");
                }
                return;
            }
            if ($session.nps.isLastQuestion && $session.nps.lengthWithComments > 2) {
                Answer.say("Last_Question");
            }
            Analytics.setCallStatus(question.callStatus);
            go("/NPS/AskQuestion");
    
    state: AskQuestion
        scriptEs6:
            const question = $session.nps.question;
            Utils.setRetrievalState();
            if (question.type === "rate") {
                Answer.fromObject(question.phrase, "* ($repeat<$NumberRepeat>/$rate) *");
            } else {
                Answer.fromObject(question.phrase);
            }
            switch (question.type) {
                case "scale":
                    go("./WaitForScaleAnswer");
                    break;
                case "rate":
                    go("./WaitForRateAnswer");
                    break;
                default:
                    go("./WaitForOpenAnswer");
                    break;
            }

        state: WaitForScaleAnswer
            scriptEs6:
                if (!Utils.testMode()) {
                    Local.answerBargeInEmotions();
                }
                $session.npsRootState = $.currentState;
            
            state: BargeInIntent || noContext = true
                event: bargeInIntent
                # Пока на ES5, т.к. $nlp.matchPatterns недоступен в ES6
                script:
                    var bargeInIntentStatus = $dialer.getBargeInIntentStatus();
                    var audioIndex = parseInt(bargeInIntentStatus.bargeInIf);
                    var text = bargeInIntentStatus.text;
                    // проверяем какой паттерн сматчился, забираем его индекс из массива
                    checkScale(text);
                    // сравниваем индекс паттерна и индекс аудио
                    if (parseInt($temp.bargeInIndex) < audioIndex) {
                        $dialer.bargeInInterrupt(true);
                    }
                
            state: GetAnswer
                scriptEs6:
                    Utils.noRedial(true);
                if: !$temp.detectedAnswerIndex || !$session.nps.question.answersValues[$temp.detectedAnswerIndex]
                    go!: /NPS/AskQuestion/LocalCatchAll
                else:
                    scriptEs6:
                        let index;
                        try {
                            index = parseInt($temp.detectedAnswerIndex);
                        } catch (e) {
                            Logger.warn("[GetAnswer] Got error while parsing answer index. Setting 0", e);
                            index = 0;
                        }
                        $temp.detectedAnswerIndex = index;
                        if ($temp.detectedAnswerIndex === 5) {
                            go("/NPS/AskQuestion/WaitForScaleAnswer/NoEmotions");
                            return;
                        }
                        const question = $session.nps.question;
                        const npsResult = question.answersValues[index];
                        const query = $request?.query || $parseTree?.text;
                        (await session()).nps.saveResult(npsResult, query);
                        Analytics.saveValue(question.marketingPerformance, npsResult);
                        Analytics.saveValue(question.marketingPerformance + " Текст", query);
                        go("/NPS/PostProcessing");

            state: NoEmotions
                q: * (~никакой/ничего/не могу/не знаю) *
                scriptEs6: Answer.say();
                
                state: Yes
                    q: * ($yes/$agree) * || fromState = "/NPS/AskQuestion/WaitForScaleAnswer/NoEmotions", onlyThisState = true
                    event: noMatch
                    event: speechNotRecognized
                    scriptEs6:
                        $session.wasInNoEmotions = true;
                        Analytics.saveValue($session.nps.question.marketingPerformance, null);
                        Analytics.saveValue($session.nps.question.marketingPerformance + " Текст", $request.query);
                        Answer.say("Understood");
                    go!: /NPS/InitQuestion
                
                state: No
                    q: * ($no/$disagree/~какой вариант*/могу $weight<+0.5>) * || fromState = "/NPS/AskQuestion/WaitForScaleAnswer/NoEmotions", onlyThisState = true
                    scriptEs6:
                        Answer.say("NoEmotions_No");
                        // TODO перенести проверку testMode внутрь методов с барджином
                        if (!Utils.testMode()) {
                            Local.answerBargeInEmotions();
                        }
                    go!: /NPS/AskQuestion/WaitForScaleAnswer

        state: WaitForRateAnswer
            scriptEs6:
                $session.npsRootState = $.currentState;
            
            state: GetAnswer
                # Вес прибавлен, т.к. вес DateTime иногда превышает вес Number на 0,05
                q: * ($repeat<$NumberRepeat>/$rate) * $weight<+0.05>
                q: * {($goodWordEvaluation/$neutralWordEvaluation/$badWordEvaluation) * ($repeat<$NumberRepeat>/$rate)} *
                q: * ($recommendNotToSmoke) * ($repeat<$NumberRepeat>/$rate) *
                scriptEs6:
                    Utils.noRedial(true);
                    if (!NLU.checkSameNumbers()) {
                        go("/NPS/AskQuestion/LocalCatchAll");
                        return;
                    }
                    const question = $session.nps.question;
                    let rate = NLU.checkRateValidity(question.range[0], question.range[1]);
                    rate = parseInt(rate);
                    if (!Number.isFinite(rate)) {
                        go("/NPS/AskQuestion/LocalCatchAll");
                        return;
                    }
                    $temp.detectedAnswerIndex = rate;
                    const query = $parseTree.text || $request.query;
                    Analytics.saveValue(question.marketingPerformance, rate);
                    Analytics.saveValue(`${question.marketingPerformance} Текст`, query);
                    (await session()).nps.saveResult(rate, query);
                    if (!$session.nps.isLastQuestion) {
                        Answer.say("ThanksWrote");
                    }
                    go("/NPS/PostProcessing");


        state: WaitForOpenAnswer
            scriptEs6:
                // TODO Выбор фразы при тишине должен зависеть не от сценария, а от вопроса!
                $temp.silencePhrases = $commonAnswers.Silence["TNPS Open Question"][$session.nps.structure.alternativeStart];
            LongListening:
                name = OpenAnswer
                duration = 67
                silencePhrases = {{JSON.stringify($temp.silencePhrases)}}
                silenceLimit = 1
                okState = /NPS/AskQuestion/WaitForOpenAnswer/GotOpenAnswer
                silenceState = /NPS/AskQuestion/WaitForOpenAnswer/Silence
                hangUpState = /NPS/AskQuestion/WaitForOpenAnswer/LocalHangUp
                robotState = /NPS/AskQuestion/WaitForOpenAnswer/YouAreRobot

            state: GotOpenAnswer
                scriptEs6:
                    const answer = $temp.longListeningResult?.comment;
                    if (!answer) {
                        go("../Silence");
                        return;
                    }
                    const question = $session.nps.question;
                    Analytics.saveValue(question.marketingPerformance, answer);
                    (await session()).nps.saveResult(answer, answer);
                    if (!$session.nps.isLastQuestion) {
                        Answer.say("Understood");
                    }
                    go("/NPS/PostProcessing");
            
            state: Silence
                # Ничего не записываем, просто идем дальше по сценарию
                go!: /NPS/InitQuestion
            
            state: LocalHangUp
                scriptEs6:
                    const answer = $temp.longListeningResult?.comment;
                    if (answer) {
                        Analytics.saveValue(question.marketingPerformance, answer);
                        (await session()).nps.saveResult(answer, answer);
                    }
                    go("/Events_ClientHangup");
        
            # TODO Scenario убрать бесконечный цикл
            state: YouAreRobot
                scriptEs6:
                    const answerObj = $commonAnswers.YouAreRobot["TNPS Open Question"][$session.nps.structure.alternativeStart];
                    Answer.fromObject(answerObj);
                    $temp.silencePhrases = $commonAnswers.Silence["TNPS Open Question"][$session.nps.structure.alternativeStart];
                LongListening:
                    name = OpenAnswer
                    duration = 67
                    silencePhrases = {{JSON.stringify($temp.silencePhrases)}}
                    silenceLimit = 2
                    okState = /NPS/AskQuestion/WaitForOpenAnswer/GotOpenAnswer
                    silenceState = /NPS/AskQuestion/WaitForOpenAnswer/Silence
                    hangUpState = /NPS/AskQuestion/WaitForOpenAnswer/LocalHangUp
                    robotState = /NPS/AskQuestion/WaitForOpenAnswer/YouAreRobot
                go!: ..


        state: LocalCatchAll || noContext = true
            q: * (менее/меньше/более/больше) [чем] $Number *
            q: * ($goodWordEvaluation/$neutralWordEvaluation/$badWordEvaluation/a) *
            q: * $recommendNotToSmoke *
            q: нет
            event: noMatch
            scriptEs6:
                const question = $session.nps.question;
                Analytics.saveValue(`${question.marketingPerformance} Текст`, $request.query);
                if (Utils.counter(`Fallback_${$session.nps.currentQuestionId}`) <= CATCHALL_LIMIT) {
                    Answer.common("CatchAll", question.commonAnswers);
                    changeState($session.npsRootState);
                } else {
                    Answer.say("CatchAll_Last");
                    HangUp.noRedialHangUp();
                }

        state: Silence || noContext = true
            event: speechNotRecognized
            q: $regexp</testSilence>
            scriptEs6:
                if (Utils.counter(`Fallback_${$session.nps.currentQuestionId}`) <= CATCHALL_LIMIT) {
                    Answer.common("Silence", $session.nps.question.commonAnswers);
                } else {
                    Answer.say("Silence_Last");
                    HangUp.noRedialHangUp();
                }

        state: CantHearYou
            q: * $cantHearYou *
            scriptEs6: Answer.say();
            go!: /NPS/AskQuestion

        state: NotApply
            q: $notApply
            scriptEs6:
                Answer.say("NotApply");
                Analytics.saveValue("Клиент не обращался", "1");
                Analytics.setCallStatus("Клиент не обращался");
                HangUp.noRedialHangUp();

        state: YouAreRobot || noContext = true
            q: $youAreRobot
            scriptEs6:
                // TODO перепроверить фукнции и словари ответов
                // TODO рефакторинг стратегии ответов
                const question = $session.nps.question;
                if ($session.nps.currentQuestionId === 60 || $session.nps.currentQuestionId === 62) {
                    Answer.common("YouAreRobot", "CheckUp");
                } else if (question.marketingPerformance === "CES Process") {
                    Answer.fromObject($commonAnswers.YouAreRobot["CES Process"][$session.nps.structure.alternativeStart]);
                } else {
                    Answer.common("YouAreRobot", question.commonAnswers);
                }
            
        state: LocalRepeat || noContext = true
            q: $repeatLocal
            scriptEs6:
                Utils.retrievalTransition();

    state: PostProcessing
        scriptEs6:
            $session.currentCampaign.data.hasAnswered = true;
            const question = $session.nps.question;
            const index = $temp.detectedAnswerIndex;
            if (question.type !== "scale" || $session.nps.isLastQuestion) {
                if (question.blocksPromo !== undefined && index !== undefined && index < question.blocksPromo) {
                    Logger.info("[GetAnswer] Setting low rate flag");
                    $session.lowRate = true;
                }
            }
            go(question.commentByAnswer ? "/NPS/AskForComment": "/NPS/InitQuestion")

    state: AskForComment
        scriptEs6:
            $session.currentCommentId = $session.nps.question.commentByAnswer?.[$temp.detectedAnswerIndex];
            const commentId = $session.currentCommentId;
            if (commentId) {
                $temp.commentInfo = $Comments[commentId];
            }
        if: $temp.commentInfo
            scriptEs6:
                $temp.silencePhrases = $Comments.silence[$temp.commentInfo.silence];
                Answer.fromObject($temp.commentInfo.phrase);
            LongListening:
                name = Comment
                duration = 67
                silencePhrases = {{JSON.stringify($temp.silencePhrases)}}
                silenceLimit = 1
                okState = /NPS/AskForComment/GotComment
                silenceState = /NPS/AskForComment/Silence
                hangUpState = /NPS/AskForComment/LocalHangUp
                noMoreCallsState = /NPS/AskForComment/NoMoreCalls
        else:
            scriptEs6: Logger.warn("[AskForComment] no comment info found");
            go!: /NPS/InitQuestion
        
        state: GotComment
            scriptEs6:
                const answer = $temp.longListeningResult?.comment;
                if (!answer) {
                    Logger.warn("[GotComment] No answer provided by longListening");
                    go("../Silence");
                    return;
                }
                const question = $session.nps.question;
                Analytics.saveValue(`${question.marketingPerformance} Комментарий`, answer);
                const commentInfo = $Comments[$session.currentCommentId];
                (await session()).nps.saveComment(answer, commentInfo);
                if (!$session.nps.isLastQuestion) {
                    Answer.say("Thanks_Colleagues");
                }
            go!: /NPS/InitQuestion
        
        state: Silence
            # Ничего не записываем, просто идем дальше по сценарию
            go!: /NPS/InitQuestion
        
        state: LocalHangUp
            scriptEs6:
                const answer = $temp.longListeningResult?.comment;
                if (answer) {
                    const question = $session.nps.question;
                    Analytics.saveValue(`${question.marketingPerformance} Комментарий`, answer);
                    const commentInfo = $Comments[$session.currentCommentId];
                    (await session()).nps.saveComment(answer, commentInfo);
                }
                go("/Events_ClientHangup");
        
        state: NoMoreCalls
            scriptEs6:
                const answer = $temp.longListeningResult?.comment;
                if (answer) {
                    const question = $session.nps.question;
                    Analytics.saveValue(`${question.marketingPerformance} Комментарий`, answer);
                    const commentInfo = $Comments[$session.currentCommentId];
                    (await session()).nps.saveComment(answer, commentInfo);
                }
                Answer.say("NoMoreCalls_Last");
                HangUp.noRedialHangUp();
