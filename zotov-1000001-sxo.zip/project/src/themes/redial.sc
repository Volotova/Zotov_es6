theme: /Redial

    state: CallBackLater
        q: $callback || fromState = /Start
        q: $callback || fromState = /NPS/AskQuestion
        q: * $disagree * $weight<+0.1>
        q: * (не/ни) до [$AnyWord] (этого/чего/всего/того) *
        q: * (не [очень] удобно/неудобно) *
        q: *
        q: $noHaveNoTime
        event: speechNotRecognized
        scriptEs6:
            if (Utils.counter("callbackLater") <= 1 && !$session.saidObsceneNoCalls) {
                Answer.say("CallBackLater");
            } else {
                Analytics.saveValue("Удобно ли говорить (2я попытка)", "Нет");
                Analytics.saveValue("Удобно ли говорить (2я попытка) Текст", $parseTree.text || $request.query);
                Answer.say("DontCallBack");
                Analytics.setCallStatus("Нет времени");
                HangUp.noRedialHangUp();
            }

        state: DontCallBack
            q: $noCallsRedial $weight<1.1>
            q: $noInterest
            q: * $repeat<$disagree> * $weight<+0.1>
            scriptEs6:
                Answer.say("DontCallBack");
                Analytics.saveValue("Удобно ли говорить (2я попытка)", "Нет");
                Analytics.saveValue("Удобно ли говорить (2я попытка) Текст", $parseTree.text);
                Analytics.setCallStatus("Клиент просит больше не звонить");
                HangUp.noRedialHangUp();
        
        state: MarketingPerformance
            q: * $agree * || fromState = "/Redial/CallBackLater"
            q: $speakNow || fromState = "/Redial/CallBackLater"
            q: $stateWhy || fromState = "/Redial/CallBackLater"
            scriptEs6:
                Analytics.saveValue("Удобно ли говорить (2я попытка)", "Да");
                Analytics.saveValue("Удобно ли говорить (2я попытка) Текст", $parseTree.text);
                Answer.say();
            if: $session.nps && $session.nps.question
                go!: /NPS/AskQuestion
            else:
                go!: /NPS/InitQuestion
