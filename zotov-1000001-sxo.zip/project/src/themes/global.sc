theme: /Global

    # Не звоните мне больше
    state: NoMoreCalls
        q!: $noMoreCalls
        scriptEs6:
            Analytics.setCallStatus("Клиент просит больше не звонить");
            Utils.noRedial(true);
            if (Utils.counter("noMoreCalls") === 1) {
                $session.saidObsceneNoCalls = true;
                const ctx = $session.stateForRetrieval?.value == "/Start" ? "Start" : "Global";
                Answer.fromObject($Answers.NoMoreCalls[ctx]);
                Utils.retrievalTransition();
            } else {
                Answer.say("NoMoreCalls_Last");
                HangUp.noRedialHangUp();
            }

    # Клиент ругается
    state: Obscenity
        q!: * ($mat/$obscenity) * $weight<+1.0>
        scriptEs6:
            Analytics.setCallStatus("Клиент ругается");
            Utils.noRedial(true);
            if (Utils.counter("obscenity") <= 1) {
                $session.saidObsceneNoCalls = true;
                const ctx = $session.stateForRetrieval?.value == "/Start" ? "Start" : "Global";
                Answer.fromObject($Answers.Obscenity[ctx]);
                Utils.retrievalTransition();
            } else {
                Answer.say("Obscenity_Last");
                HangUp.noRedialHangUp();
            }

    # Перенести в longListening
    # Клиент не курит
    state: DontSmoke
        q!: $dontSmoke
        scriptEs6:
            Answer.say();
            Analytics.setCallStatus("Уточняем курит ли клиент");

        state: LocalCatchAll || noContext = true
            event: speechNotRecognized
            event: noMatch
            scriptEs6:
                if (Utils.counter() <= 1) {
                    Answer.say("DontSmoke_CatchAll");
                } else {
                    $reactions.transition("/Global/DontSmoke/DeleteAccount");
                }

        state: DeleteAccount
            q: * ($yes/$agree) *
            q: * ($dontSmoke/$stopPast/абсолютно/ничего/никак*) *
            scriptEs6:
                Utils.noRedial(true);
                Analytics.setCallStatus("Клиент не курит");
                Analytics.saveValue("Клиент курит", "Нет");
                Answer.say("DeleteAccount");
                HangUp.noRedialHangUp();

        state: YesSmoke
            q: * ($no/$disagree) *
            q: * {(использ*/польз*/употребл*) * [$anotherEquipment/$device/$cigarette]} *
            q: * {$yesISmoke * [$anotherEquipment/$device/$cigarette]} *
            q: * ($anotherEquipment/$device/$cigarette) *
            q: {$device [[и] $device] [$AnyWord] [$AnyWord] ({больше ничего [не [употребляю/курю]]})} || fromState = "/Global/DontSmoke"
            scriptEs6:
                Analytics.setCallStatus("Клиент курит");
                Analytics.saveValue("Клиент курит", "Да");
                const ctx = $session.stateForRetrieval?.value == "/Start" ? "Start" : "Global";
                Answer.fromObject($Answers.YesSmoke[ctx]);
                Utils.retrievalTransition();

    state: CantHearYou || noContext = true
        q!: * $cantHearYou *
        scriptEs6: Answer.say();
        go!: /Common/Repeat

    state: AutoresponderLocal
        q: $repeat<$autoresponder> || fromState = /Start
        q: $repeat<$autoresponder> || fromState = /NPS/AskQuestion
        scriptEs6:
            Answer.say("ItsAnsweringMachine");
        go!: /Autoresponder
