# COMMON PMI
require: common/requirements.sc
require: common/test/test.sc
require: common/integrations/bpm/sendNpsResult.js
    type = scriptEs6
    name = $SendNpsResult
require: common/services/bargeIn.sc
require: common/services/repeat.sc

# ES6 SCRIPTS
require: scripts/functions.js
    type = scriptEs6
    name = Local
require: scripts/npsScenario.js
    type = scriptEs6
    name = $NPSScenario

# ES5 SCRIPTS
require: scriptsEs5/functions.js

# DICTS
require: dictionaries/answers.yaml
    var = $Answers
require: dictionaries/mockTests.yaml
    var = $MockTests
require: dictionaries/comments.yaml
  var = $Comments
require: dictionaries/commonAnswers.yaml
  var = $commonAnswers
require: dictionaries/npsQuestions.yaml
  var = $Questions
require: dictionaries/scales.yaml
  var = $Scales
require: dictionaries/scenarios.yaml
  var = $Scenarios
require: dictionaries/emotions.yaml
  var = $Emotions

# # THEMES
require: themes/redial.sc
require: themes/global.sc
require: themes/nps.sc
require: patterns/patterns.sc
