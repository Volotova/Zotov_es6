require: requirements.sc

theme: /
    
    state: StartIncoming
        scriptEs6:
            Analytics.setCallStatus("Приветствие-входящий звонок");
            if ($session.currentCampaign?.data?.hasAnswered) {
                Answer.say("StartIncoming_hasAnswered");
                HangUp.noRedialHangUp();
            } else {
                Answer.say();
            }
        
        state: ShallContinue
            event: speechNotRecognized
            q: *
            scriptEs6:
                await Analytics.setCallStatus("Уточняем удобно ли говорить");
                Answer.say("StartIncoming_ShallContinue");
            go: /Start
    
    state: Start
        q!: $regex</start>
        scriptEs6:
            await Init.initSession();
            Analytics.setCallStatus("Приветствие");
            $session.nps = new NPSScenario().init();
            if (Utils.isIncoming() || $request.query === "/incoming start") {
                go("/StartIncoming");
                return;
            }

            const nps = await $session.nps;
            const startPhraseId = nps.structure.alternativeStart || nps.lengthWithComments;
            Answer.say();
            Answer.fromObject($Answers.Start_Purpose[startPhraseId]);
            Utils.setRetrievalState($.currentState, true);

        state: Concordance
            q: * ($agree/$speakNow) *
            scriptEs6:
                Analytics.saveValue("Удобно ли говорить", "Да");
                Analytics.saveValue("Удобно ли говорить Текст", $parseTree.text);
                if ($parseTree.value === "fast" || $session.wasDoubt) {
                    Answer.say();
                } else {
                    Answer.say("Thanks");
                }
                if (Utils.isIncoming()) {
                    Answer.addPause();
                }
            go!: /NPS/InitQuestion

        state: AgainYouCalling
            q: * $againYouCalling *
            scriptEs6:
                $session.wasDoubt = true;
                Analytics.saveValue("Удобно ли говорить", "Нет");
                Analytics.saveValue("Удобно ли говорить Текст", $parseTree.text);
                Answer.say();
            
            state: No
                q: * ($no/$disagree/[$no] не хорошо) *
                go!: /Redial/CallBackLater/DontCallBack

        state: WhatSubject
            q: $stateWhy
            q: * $cantHearYou *
            q: * $repeat *
            scriptEs6:
                $session.wasDoubt = true;
                Answer.say("Start_WhatSubject");

            state: No
                q: * ($no/$disagree/[$no] не хорошо) *
                scriptEs6:
                    if (Utils.isLastAttempt()) {
                        Analytics.saveValue("Удобно ли говорить", "Нет");
                        Analytics.saveValue("Удобно ли говорить Текст", $parseTree.text);
                        Answer.say("Start_WhatSubject_No");
                        $session.definedEndStatus = "Нет времени";
                        HangUp.noRedialHangUp();
                    } else {
                        go("/Redial/CallBackLater");
                    }

        state: NotInterested || noContext = true
            q: $noInterest 
            scriptEs6:
                $session.wasDoubt = true;
                if (counter("noInterest") < 2) {
                    Answer.say("Start_NotInterested");
                } else {
                    Answer.say("Start_NotInterested_LastCall");
                    HangUp.noRedialHangUp();
                }

        state: NoHaveNoTime
            q: $noHaveNoTime
            q: $noHaveNoTimeLocal || fromState = /NPS/AskQuestion
            scriptEs6:
                Analytics.saveValue("Удобно ли говорить", "Нет");
                Analytics.saveValue("Удобно ли говорить Текст", $parseTree.text);
                if (!$session.saidObsceneNoCalls) {
                    go("/Redial/CallBackLater");
                } else {
                    Answer.say("Start_NoHaveNoTime");
                    HangUp.noRedialHangUp();
                }

        state: YouAreRobot || noContext = true
            q: ($whoIsIt/$youAreRobot)
            scriptEs6:
                $session.wasDoubt = true;
                Answer.say("Start_YouAreRobot");
    
        state: LocalCatchAll || noContext = true
            event: speechNotRecognized
            event: noMatch
            q: a
            scriptEs6:
                $session.wasDoubt = true;
                if (Utils.counter() <= CATCHALL_LIMIT) {
                    Answer.say("Start_LocalCatchAll");
                } else {
                    Answer.say("Start_LastCatchAll");
                    HangUp.hangUp();
                }

    state: Goodbye
        scriptEs6:
            if ($session.lowRate) {
                const alternativeEnd = $session.nps?.structure?.alternativeEnd;
                if (alternativeEnd) {
                    const ansObj = $Answers.Goodbye[alternativeEnd] || $Answers.Goodbye.General;
                    Answer.fromObject(ansObj);
                } else {
                    Answer.fromObject($Answers.Goodbye.General);
                }
            } else {
                Answer.say("Goodbye_Promoter");
            }
            Analytics.setCallStatus("FINISHED__ACCEPTED");
            HangUp.noRedialHangUp();

    state: Reset
        q!: reset
        script:
            $session = {};
            $client = {};
            $temp = {};
        go!: /Start